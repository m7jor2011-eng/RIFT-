const {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionFlagsBits,
  Events
} = require("discord.js");

const fs = require("fs");
const path = require("path");

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID;
const REVIEW_CHANNEL_ID = process.env.REVIEW_CHANNEL_ID || "";
const STAFF_ROLE_ID = process.env.STAFF_ROLE_ID || "";

if (!TOKEN || !CLIENT_ID || !GUILD_ID) {
  throw new Error("Set DISCORD_TOKEN, CLIENT_ID and GUILD_ID in Render Environment Variables.");
}

const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "reputation.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

let db = {
  users: {},
  requests: {}
};

if (fs.existsSync(DATA_FILE)) {
  try {
    db = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    console.log("Could not read reputation.json; starting with empty data.");
  }
}

function save() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

function userData(id) {
  if (!db.users[id]) {
    db.users[id] = {
      rp: { level: 1, points: 0, hours: 0, cleanDays: 0 },
      discord: { level: 1, points: 0, hours: 0, cleanDays: 0 },
      achievements: 0,
      warnings: 0,
      promotions: 1,
      history: []
    };
    save();
  }
  return db.users[id];
}

function isStaff(interaction) {
  if (interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return true;
  if (!STAFF_ROLE_ID) return false;
  return interaction.member?.roles?.cache?.has(STAFF_ROLE_ID) || false;
}

function addHistory(id, item) {
  const d = userData(id);
  d.history.unshift({
    ...item,
    at: new Date().toISOString()
  });
  d.history = d.history.slice(0, 100);
}

const LEVELS = [
  { level: 1, name: "Member", points: 0 },
  { level: 2, name: "Trusted Member", points: 10 },
  { level: 3, name: "Experienced Member", points: 20 },
  { level: 4, name: "Senior Member", points: 40 },
  { level: 5, name: "Advanced Member", points: 60 },
  { level: 6, name: "Elite Member", points: 80 },
  { level: 7, name: "Legend Member", points: 100 },
  { level: 8, name: "Master Member", points: 120 },
  { level: 9, name: "Grand Master", points: 150 },
  { level: 10, name: "Supreme Member", points: 200 }
];

function levelFromPoints(points) {
  let current = LEVELS[0];
  for (const row of LEVELS) {
    if (points >= row.points) current = row;
  }
  return current;
}

function nextLevel(points) {
  return LEVELS.find(x => x.points > points) || null;
}

function progressText(points) {
  const current = levelFromPoints(points);
  const next = nextLevel(points);
  if (!next) return `Level ${current.level} — MAX`;
  return `${points} / ${next.points}`;
}

function mainEmbed(user) {
  const d = userData(user.id);
  const rp = levelFromPoints(d.rp.points);
  const dis = levelFromPoints(d.discord.points);

  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle("Reputation Profile")
    .setDescription(`Citizen\n${user}`)
    .addFields(
      {
        name: "RP Reputation",
        value:
          `Level ${rp.level} — ${rp.name}\n` +
          `Points: ${progressText(d.rp.points)}\n` +
          `Hours: ${formatHours(d.rp.hours)}\n` +
          `Clean Days: ${d.rp.cleanDays}`,
        inline: true
      },
      {
        name: "Discord Reputation",
        value:
          `Level ${dis.level} — ${dis.name}\n` +
          `Points: ${progressText(d.discord.points)}\n` +
          `Hours: ${formatHours(d.discord.hours)}\n` +
          `Clean Days: ${d.discord.cleanDays}`,
        inline: true
      },
      {
        name: "Achievements",
        value: `${d.achievements}`,
        inline: true
      },
      {
        name: "Warnings",
        value: `${d.warnings}`,
        inline: true
      }
    )
    .setFooter({ text: "All reputation additions require proof and staff review." })
    .setTimestamp();
}

function formatHours(hours) {
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

function mainRows() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("rp_add_hours").setLabel("Add RP Hours").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("discord_add_hours").setLabel("Add Discord Hours").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("submit_achievement").setLabel("Submit Achievement").setStyle(ButtonStyle.Secondary)
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("my_profile").setLabel("My Profile").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("promotions").setLabel("Promotions").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("rewards").setLabel("Rewards").setStyle(ButtonStyle.Secondary)
    )
  ];
}

function promotionEmbed(user) {
  const d = userData(user.id);
  const rp = levelFromPoints(d.rp.points);
  const available = rp.level >= 4 && d.achievements >= 3 && d.warnings === 0;

  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle("Promotion System")
    .setDescription(
      `Current Level: ${rp.level} — ${rp.name}\n\n` +
      `Promotion status: ${available ? "Promotion Available" : "Requirements Not Completed"}\n\n` +
      `Requirements example:\n` +
      `• Required Reputation level\n` +
      `• Required clean days\n` +
      `• Approved achievements\n` +
      `• No active warnings\n` +
      `• RP / Discord activity`
    );
}

function rewardsEmbed() {
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle("Rewards")
    .setDescription(
      "Rewards are granted once when the player reaches the configured level.\n\n" +
      "Level 3 — Priority + 5,000$\n" +
      "Level 5 — Higher priority + 15,000$\n" +
      "Level 7 — High priority + 35,000$\n" +
      "Level 10 — Maximum priority + 100,000$\n\n" +
      "Final rewards and privileges are controlled by the owner/admin team."
    );
}

function levelsEmbed() {
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle("Level Requirements")
    .setDescription(
      LEVELS.map(x => `Level ${x.level} — ${x.name} — ${x.points} points`).join("\n")
    )
    .setFooter({ text: "Points are only added after an approved request." });
}

function reviewEmbed(req, guild) {
  return new EmbedBuilder()
    .setColor(0xF1C40F)
    .setTitle("Reputation Request — Pending Review")
    .addFields(
      { name: "Citizen", value: `<@${req.userId}>`, inline: true },
      { name: "Type", value: req.type, inline: true },
      { name: "Requested", value: req.amount ? formatHours(req.amount) : "+1 Reputation", inline: true },
      { name: "Description", value: req.description || "None" },
      { name: "Evidence", value: req.evidence || "See attached evidence / command attachment." },
      { name: "Status", value: "Pending Review", inline: true }
    )
    .setFooter({ text: `Request ID: ${req.id}` })
    .setTimestamp();
}

function reviewButtons(id) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`approve:${id}`).setLabel("Approve").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`deny:${id}`).setLabel("Deny").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`view:${id}`).setLabel("View Profile").setStyle(ButtonStyle.Secondary)
  );
}

async function sendReview(req, client) {
  if (!REVIEW_CHANNEL_ID) {
    console.log("REVIEW_CHANNEL_ID is not set. Request stored but no review message was sent.");
    return null;
  }

  const channel = await client.channels.fetch(REVIEW_CHANNEL_ID).catch(() => null);
  if (!channel || !channel.isTextBased()) return null;

  const message = await channel.send({
    embeds: [reviewEmbed(req)],
    components: [reviewButtons(req.id)]
  });

  req.reviewMessageId = message.id;
  save();
  return message;
}

async function notifyUser(client, req, text) {
  const user = await client.users.fetch(req.userId).catch(() => null);
  if (!user) return;
  await user.send({ content: text }).catch(() => {});
}

const commands = [
  new SlashCommandBuilder()
    .setName("reputation")
    .setDescription("Open the Reputation System"),

  new SlashCommandBuilder()
    .setName("rep")
    .setDescription("Open your Reputation Profile"),

  new SlashCommandBuilder()
    .setName("proof")
    .setDescription("Submit a reputation proof for staff review")
    .addStringOption(o =>
      o.setName("type")
        .setDescription("Proof type")
        .setRequired(true)
        .addChoices(
          { name: "RP Hours", value: "RP Hours" },
          { name: "Discord Hours", value: "Discord Hours" },
          { name: "Achievement", value: "Achievement" }
        )
    )
    .addNumberOption(o =>
      o.setName("hours")
        .setDescription("Hours to request for RP/Discord Hours")
        .setRequired(false)
        .setMinValue(0.25)
    )
    .addAttachmentOption(o =>
      o.setName("evidence")
        .setDescription("Image or video proof")
        .setRequired(true)
    )
    .addStringOption(o =>
      o.setName("description")
        .setDescription("Explain what the proof shows")
        .setRequired(true)
        .setMaxLength(1000)
    ),

  new SlashCommandBuilder()
    .setName("levels")
    .setDescription("Show the level requirements"),

  new SlashCommandBuilder()
    .setName("addpoints")
    .setDescription("Staff: add approved reputation points")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addUserOption(o => o.setName("user").setDescription("Player").setRequired(true))
    .addStringOption(o => o.setName("side").setDescription("RP or Discord").setRequired(true).addChoices(
      { name: "RP", value: "rp" },
      { name: "Discord", value: "discord" }
    ))
    .addIntegerOption(o => o.setName("points").setDescription("Points").setRequired(true).setMinValue(1))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(true)),

  new SlashCommandBuilder()
    .setName("warning")
    .setDescription("Staff: add a warning")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addUserOption(o => o.setName("user").setDescription("Player").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(true))
].map(c => c.toJSON());

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers]
});

client.once(Events.ClientReady, async ready => {
  console.log(`Online as ${ready.user.tag}`);

  const rest = new REST({ version: "10" }).setToken(TOKEN);

  try {
    await rest.put(
      Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
      { body: commands }
    );
    console.log("Slash commands registered.");
  } catch (e) {
    console.error("Command registration error:", e);
  }
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === "reputation" || interaction.commandName === "rep") {
        return interaction.reply({
          embeds: [mainEmbed(interaction.user)],
          components: mainRows()
        });
      }

      if (interaction.commandName === "levels") {
        return interaction.reply({ embeds: [levelsEmbed()] });
      }

      if (interaction.commandName === "proof") {
        const type = interaction.options.getString("type");
        const amount = interaction.options.getNumber("hours");
        const evidence = interaction.options.getAttachment("evidence");
        const description = interaction.options.getString("description");

        if ((type === "RP Hours" || type === "Discord Hours") && !amount) {
          return interaction.reply({
            content: "For an hours request, enter the number of hours you are proving.",
            ephemeral: true
          });
        }

        const id = `${Date.now()}-${interaction.user.id}`;
        const req = {
          id,
          userId: interaction.user.id,
          type,
          amount: amount || null,
          evidence: evidence.url,
          description,
          status: "pending",
          createdAt: new Date().toISOString()
        };

        db.requests[id] = req;
        save();

        await sendReview(req, client);

        return interaction.reply({
          content:
            "Your reputation request has been submitted.\n" +
            "Status: Pending Review\n\n" +
            "The requested hours/points will not be added until staff approve the evidence.",
          ephemeral: true
        });
      }

      if (interaction.commandName === "addpoints") {
        if (!isStaff(interaction)) return interaction.reply({ content: "Staff only.", ephemeral: true });

        const target = interaction.options.getUser("user");
        const side = interaction.options.getString("side");
        const points = interaction.options.getInteger("points");
        const reason = interaction.options.getString("reason");

        const d = userData(target.id);
        const before = levelFromPoints(d[side].points);
        d[side].points += points;
        const after = levelFromPoints(d[side].points);

        addHistory(target.id, {
          action: "points_added",
          side,
          points,
          reason,
          by: interaction.user.id
        });
        save();

        return interaction.reply({
          content:
            `${target} received +${points} ${side.toUpperCase()} reputation points.\n` +
            `Level: ${before.level} → ${after.level}`,
          ephemeral: false
        });
      }

      if (interaction.commandName === "warning") {
        if (!isStaff(interaction)) return interaction.reply({ content: "Staff only.", ephemeral: true });

        const target = interaction.options.getUser("user");
        const reason = interaction.options.getString("reason");
        const d = userData(target.id);

        d.warnings += 1;
        d.rp.points = Math.max(0, d.rp.points - 2);
        d.discord.points = Math.max(0, d.discord.points - 2);

        addHistory(target.id, {
          action: "warning",
          reason,
          by: interaction.user.id
        });
        save();

        return interaction.reply({
          content: `${target} received a warning. Reputation was reduced according to the configured penalty.`,
          ephemeral: false
        });
      }
    }

    if (interaction.isButton()) {
      const id = interaction.customId;

      if (id === "my_profile") {
        return interaction.update({ embeds: [mainEmbed(interaction.user)], components: mainRows() });
      }

      if (id === "promotions") {
        return interaction.update({
          embeds: [promotionEmbed(interaction.user)],
          components: mainRows()
        });
      }

      if (id === "rewards") {
        return interaction.update({
          embeds: [rewardsEmbed()],
          components: mainRows()
        });
      }

      if (id === "rp_add_hours" || id === "discord_add_hours") {
        const type = id === "rp_add_hours" ? "RP Hours" : "Discord Hours";

        return interaction.reply({
          content:
            `To submit ${type}, use:\n` +
            "```/proof type:" + type + " hours:1.5 evidence:[image/video] description:[explain the proof]```\n" +
            "The evidence is sent to staff for review. Nothing is added automatically.",
          ephemeral: true
        });
      }

      if (id === "submit_achievement") {
        return interaction.reply({
          content:
            "Submit an achievement with:\n" +
            "```/proof type:Achievement evidence:[image/video] description:[explain the achievement]```\n" +
            "Staff must approve it before it affects your reputation.",
          ephemeral: true
        });
      }

      if (id.startsWith("view:")) {
        const req = db.requests[id.split(":")[1]];
        if (!req) return interaction.reply({ content: "Request not found.", ephemeral: true });

        const target = await client.users.fetch(req.userId).catch(() => null);
        if (!target) return interaction.reply({ content: "Player not found.", ephemeral: true });

        return interaction.reply({
          embeds: [mainEmbed(target)],
          ephemeral: true
        });
      }

      if (id.startsWith("approve:") || id.startsWith("deny:")) {
        if (!isStaff(interaction)) {
          return interaction.reply({ content: "Only staff can review reputation requests.", ephemeral: true });
        }

        const reqId = id.split(":")[1];
        const req = db.requests[reqId];

        if (!req) return interaction.reply({ content: "Request not found.", ephemeral: true });
        if (req.status !== "pending") {
          return interaction.reply({ content: `This request is already ${req.status}.`, ephemeral: true });
        }

        if (id.startsWith("deny:")) {
          req.status = "denied";
          req.reviewedBy = interaction.user.id;
          req.reviewedAt = new Date().toISOString();
          addHistory(req.userId, {
            action: "request_denied",
            requestId: req.id,
            type: req.type,
            by: interaction.user.id
          });
          save();

          await interaction.update({
            embeds: [
              new EmbedBuilder()
                .setColor(0xED4245)
                .setTitle("Request Denied")
                .setDescription(`<@${req.userId}>\n\nThe evidence was not approved by staff.`)
                .addFields({ name: "Reviewed By", value: `${interaction.user}` })
            ],
            components: []
          });

          await notifyUser(client, req, "Reputation Request Denied\nYour submitted evidence was not approved by staff.");
          return;
        }

        const d = userData(req.userId);

        if (req.type === "RP Hours") {
          d.rp.hours += req.amount;
        } else if (req.type === "Discord Hours") {
          d.discord.hours += req.amount;
        } else if (req.type === "Achievement") {
          d.achievements += 1;
          d.rp.points += 1;
        }

        req.status = "approved";
        req.reviewedBy = interaction.user.id;
        req.reviewedAt = new Date().toISOString();

        addHistory(req.userId, {
          action: "request_approved",
          requestId: req.id,
          type: req.type,
          amount: req.amount,
          by: interaction.user.id
        });

        save();

        const rp = levelFromPoints(d.rp.points);
        const dis = levelFromPoints(d.discord.points);

        await interaction.update({
          embeds: [
            new EmbedBuilder()
              .setColor(0x57F287)
              .setTitle("Request Approved")
              .setDescription(`<@${req.userId}>`)
              .addFields(
                { name: "Type", value: req.type, inline: true },
                { name: "Added", value: req.amount ? formatHours(req.amount) : "+1 Achievement", inline: true },
                { name: "RP Level", value: `Level ${rp.level}`, inline: true },
                { name: "RP Points", value: `${d.rp.points}`, inline: true },
                { name: "Discord Level", value: `Level ${dis.level}`, inline: true },
                { name: "Reviewed By", value: `${interaction.user}`, inline: true }
              )
          ],
          components: []
        });

        await notifyUser(
          client,
          req,
          `Reputation Request Approved\n${req.type}\nAdded: ${req.amount ? formatHours(req.amount) : "+1 Achievement"}\nYour profile has been updated.`
        );
      }
    }
  } catch (error) {
    console.error(error);

    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: "An error occurred while processing the request.",
        ephemeral: true
      }).catch(() => {});
    }
  }
});

client.login(TOKEN);
