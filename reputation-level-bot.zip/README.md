# Discord Reputation & Level System

## Render
Build Command:
`npm install`

Start Command:
`node index.js`

## Environment Variables
- DISCORD_TOKEN = Discord bot token
- CLIENT_ID = Discord application/client ID
- GUILD_ID = Discord server ID
- REVIEW_CHANNEL_ID = channel ID where staff review requests
- STAFF_ROLE_ID = optional staff role ID

## Commands
- `/reputation` — opens the main Embed dashboard
- `/rep` — opens the player's profile
- `/proof` — submits an image/video proof for staff review
- `/levels` — shows level requirements
- `/addpoints` — staff-only manual reputation points
- `/warning` — staff-only warning and configured reputation penalty

## Important Discord limitation
Discord slash-command modals cannot contain a native file-upload field. Therefore the Add Hours / Submit Achievement buttons tell the player to use `/proof`, which has a real Discord attachment field for images/videos. This preserves the requested proof-and-review workflow.

## Level rule
Approved hours are stored as activity hours. They do NOT automatically raise the level.
Level progression is controlled by approved reputation points and the configured requirements. Every point-producing proof is reviewed by staff before it is applied.
